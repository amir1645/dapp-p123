module.exports = {
	extends: '../../../.eslintrc.test.js',
	parserOptions: {
		project: './tsconfig.json',
		tsconfigRootDir: __dirname,
	},
};
