export default {
	"name": "london",
	"comment": "HF targeted for July 2021 following the Berlin fork",
	"url": "https://github.com/ethereum/eth1.0-specs/blob/master/network-upgrades/mainnet-upgrades/london.md",
	"status": "Final",
	"eips": [1559, 3198, 3529, 3541]
}
 ;